// VARIABLES --------------------------------------------

//      OBJECTS



//      ARRAYS



//      STRINGS/CHAR



//      NUMBER/INTEGER



//      BOOLEAN



// ------------------------------------------------------------

$(document).ready(function () {

    // CODE GOES HERE

});